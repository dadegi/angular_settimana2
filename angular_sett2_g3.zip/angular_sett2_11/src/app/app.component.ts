import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Subscription } from 'rxjs';
import { User } from './models/user';
import { UsersService } from './services/users.service';


@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.scss']
})
export class AppComponent {
	title = 'angular_sett2_11';
	newUser: {
		first_name: string,
		last_name: string,
	} = {
			first_name: '',
			last_name: '',
		}
	sub!: Subscription;
	users: User[] = [];
	isLoading: boolean = false;
	error: string | undefined;

	constructor(private http: HttpClient, private usersSrv: UsersService) {
	}



	ngOnInit(): void {
		//Called after the constructor, initializing input properties, and the first call to ngOnChanges.
		//Add 'implements OnInit' to the class.
		this.onFetchUsers();
		// this.usersSrv.fullFetchUsers();
	}

	onCreateUser() {
		this.usersSrv.createUser(this.newUser).subscribe((ris) => {
			console.log(ris);
			this.users.push(ris);
		});
	}

	onFetchUsers() {
		this.fetchUsers();
	}

	onDeleteUser(id: number) {
		this.usersSrv.deleteUser(id).subscribe(() => {
			this.users = this.users.filter((user) => user.id != id);
			console.log('Utente ', id, ' cancellato!')
		})
	}

	fetchUsers() {
		this.isLoading = true;
		this.usersSrv.fetchUsers().subscribe((ris) => {
			this.isLoading = false;
			this.users = ris;
			console.log(ris);
		},(error) => {
			this.isLoading = false;
			this.error = error.message
			console.log(error);
		});
	}

	ngOnDestroy(): void {
		//Called once, before the instance is destroyed.
		//Add 'implements OnDestroy' to the class.
		this.sub.unsubscribe();
	}
}
