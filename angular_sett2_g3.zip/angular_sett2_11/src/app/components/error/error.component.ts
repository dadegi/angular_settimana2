import { Component, OnInit } from '@angular/core';
import { UsersService } from 'src/app/services/users.service';

@Component({
	selector: 'app-error',
	templateUrl: './error.component.html',
	styleUrls: ['./error.component.scss']
})
export class ErrorComponent implements OnInit {

	error: any;

	constructor(private usersSrv: UsersService) { }

	ngOnInit(): void {
		this.usersSrv.error.subscribe((err) => {
			this.error = err;
		});
	}

}
