import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from '../models/user';
import { map } from 'rxjs/operators';
import { throwError, catchError, Subject, tap } from 'rxjs';

@Injectable({
	providedIn: 'root'
})
export class UsersService {

	error = new Subject();

	constructor(private http: HttpClient) { }

	createUser(newUser: { first_name: string, last_name: string }) {
		return this.http.post<User>('https://reqres.in/api/users', newUser);
	}

	fetchUsers() {
		let params = new HttpParams().append('testo', 'ciao').append('fine', 'rosso');
		return this.http.get<{ data: User[] }>('https://reqres.in/api/users', { headers: new HttpHeaders({ 'Custom-header': 'Ciao mondo!' }), params: params }).pipe(map(ris => ris.data), catchError((er) => {
			this.error.next(er);
			console.log('Errore recupero dal server')
			return throwError({ message: 'Errore' });
		}));
	}

	fullFetchUsers() {
		this.http.get('https://reqres.in/api/users', {
			observe: 'response', responseType: 'json'
		}).pipe(tap(ris => {
			console.log(ris);
		})
		).subscribe();
	}

	deleteUser(id: number) {
		return this.http.delete(`https://reqres.in/api/users/${id}`);
	}
}
