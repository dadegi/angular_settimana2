import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Subscription } from 'rxjs';
import { User } from './models/user';
import { map } from 'rxjs/operators';


@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.scss']
})
export class AppComponent {
	title = 'angular_sett2_10';
	newUser: {
		first_name: string,
		last_name: string,
	} = {
			first_name: '',
			last_name: '',
		}
	sub!: Subscription;
	
	users: User[] | undefined;

	constructor(private http: HttpClient) {
	}



	ngOnInit(): void {
		//Called after the constructor, initializing input properties, and the first call to ngOnChanges.
		//Add 'implements OnInit' to the class.
		this.onFetchUsers();
	}

	onCreateUser() {
		this.sub = this.http.post<User>('https://reqres.in/api/users', this.newUser).subscribe((ris) => {
			console.log(ris);
			this.users?.push(ris);
		});
	}

	onFetchUsers() {
		this.fetchUsers();
	}

	fetchUsers() {
		this.sub = this.http.get<{data: User[]}>('https://reqres.in/api/users').pipe(map(ris => ris.data)).subscribe((ris) => {
			console.log(ris);
			this.users = ris;
		})
	}

	ngOnDestroy(): void {
		//Called once, before the instance is destroyed.
		//Add 'implements OnDestroy' to the class.
		this.sub.unsubscribe();
	}
}
