import { ActiveService } from './services/active.service';
import { Component } from '@angular/core';
import { interval, Subscription } from 'rxjs';

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.scss']
})
export class AppComponent {

	isActive!: boolean;
	sub!: Subscription;

	constructor(private activeSrv: ActiveService) {}

	title = 'angular_sett2_9';

	ngOnInit(): void {
		//Called after the constructor, initializing input properties, and the first call to ngOnChanges.
		//Add 'implements OnInit' to the class.
		this.sub = this.activeSrv.activeEmitter.subscribe((val) => {
			this.isActive = val;
		});
	}

	ngOnDestroy(): void {
		//Called once, before the instance is destroyed.
		//Add 'implements OnDestroy' to the class.
		this.sub.unsubscribe();
	}
}
