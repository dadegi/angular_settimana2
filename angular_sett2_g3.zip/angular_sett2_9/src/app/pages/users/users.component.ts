import { Component, OnInit } from '@angular/core';
import { interval, Observable, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';


@Component({
	templateUrl: './users.component.html',
	styleUrls: ['./users.component.scss']
})
export class UsersComponent implements OnInit {

	sub!: Subscription;

	constructor() { }

	ngOnInit(): void {

		// this.sub = interval(1000).subscribe(numero => {
		// 	console.log(numero);
		// });

		const customInterval = new Observable(observer => {
			let count = 0;
			setInterval(() => {
				observer.next(count);
				if (count === 5) {
					observer.complete();
				}
				if (count > 3) {
					observer.error(new Error('Count è troppo grande!'));
				}
				count++;
			}, 1000);
		});

		this.sub = customInterval.pipe(map((number) => {
			return `Siamo al numero ${number}`
		})).subscribe(numero => {
			console.log(numero);
		},(error) => {
			console.log(error);
			alert(error);
		}, () => {
			console.log('observable completato!');
		});
	}

	ngOnDestroy(): void {
		//Called once, before the instance is destroyed.
		//Add 'implements OnDestroy' to the class.
		this.sub.unsubscribe();
	}

}
