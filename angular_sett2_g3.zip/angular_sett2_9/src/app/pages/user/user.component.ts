import { ActiveService } from './../../services/active.service';
import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit {

  constructor(public activeSrv: ActiveService) { }

  ngOnInit(): void {
  }

}
