import { RouterModule, Route } from '@angular/router';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UsersComponent } from './users/users.component';
import { UserComponent } from './user/user.component';
import { NotFoundComponent } from './not-found/not-found.component';

const router: Route[] = [
	{
		path: 'users',
		component: UsersComponent,
		children: [
			{
				path: ':id',
				component: UserComponent
			}
		]
	},
	{
		path: '',
		redirectTo: 'users',
		pathMatch: 'full'
	},
	{
		path: '**',
		component: NotFoundComponent
	}
]

@NgModule({
	declarations: [
		AppComponent,
		UsersComponent,
  UserComponent,
  NotFoundComponent
	],
	imports: [
		BrowserModule,
		AppRoutingModule,
		RouterModule.forRoot(router)
	],
	providers: [],
	bootstrap: [AppComponent]
})
export class AppModule { }
