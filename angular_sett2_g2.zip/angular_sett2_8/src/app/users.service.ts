import { Injectable } from '@angular/core';
import { User } from './models/user';

@Injectable({
	providedIn: 'root'
})
export class UsersService {

	private users: User[] = [
		{
			id: 1,
			nome: 'Marco',
			cognome: 'Rossi',
			email: 'marco@rossi.com'
		},
		{
			id: 2,
			nome: 'Dario',
			cognome: 'Del Giudice',
			email: 'dario@delgiudice.com'
		}
	]

	constructor() { }

	getUser(idUser: number) {
		return this.users.find((user) => user.id === idUser);
	}

	getUsers() {
		return this.users;
	}
}
