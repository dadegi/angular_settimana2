import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { Subscription } from 'rxjs';
import { User } from '../models/user';
import { UsersService } from '../users.service';

@Component({
	templateUrl: './user.component.html',
	styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit {

	user!: User | undefined;
	sub!: Subscription;

	constructor(private router: ActivatedRoute, private usersSrv: UsersService) { }

	ngOnInit(): void {
		// this.user = {
		// 	id: this.router.snapshot.params['id'],
		// 	nome: this.router.snapshot.params['nome']
		// }

		this.sub = this.router.params.subscribe((params: Params) => {
			const id = +params['id'];
			this.user = this.usersSrv.getUser(id);
		})
	}

	ngOnDestroy(): void {
		//Called once, before the instance is destroyed.
		//Add 'implements OnDestroy' to the class.
		this.sub.unsubscribe;
	}

}
