import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { UsersService } from '../users.service';

@Component({
	templateUrl: './users.component.html',
	styleUrls: ['./users.component.scss']
})
export class UsersComponent implements OnInit {

	users: User[] = this.usersSrv.getUsers();

	constructor(private usersSrv: UsersService) { }

	ngOnInit(): void {
	}

}
