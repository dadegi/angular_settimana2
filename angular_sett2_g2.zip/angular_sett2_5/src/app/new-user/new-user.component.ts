import { UserService } from './../users.service';
import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
	selector: 'app-new-user',
	templateUrl: './new-user.component.html',
	styleUrls: ['./new-user.component.scss']
})
export class NewUserComponent implements OnInit {

	//@Output() onNewUser = new EventEmitter()
	name!: string;

	constructor(private userSrv: UserService) { }

	ngOnInit(): void {
	}

	onNewUser(nome: string) {
		this.userSrv.createUser(nome);
	}

}
