import { Component } from '@angular/core';
import { LogService } from './log.service';
import { UserService } from './users.service';

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.scss'],
	providers: [LogService, UserService]
})
export class AppComponent {
	title = 'angular_sett2_5';
	users = this.userSrv.users

	constructor(private userSrv: UserService) {

	}
}
