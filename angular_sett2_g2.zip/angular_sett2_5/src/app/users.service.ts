import { User } from "./user";

export class UserService {
    users: User[] = [];

	constructor() {
		
	}

	createUser(nome: string) {
		this.users.push({nome, stato:'occupato'});
	}

	updateUser(index: number, newStatus: string) {
		this.users[index].stato = newStatus;
	}
}