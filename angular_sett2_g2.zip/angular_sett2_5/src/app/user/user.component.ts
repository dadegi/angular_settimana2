import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { LogService } from '../log.service';
import { UserService } from '../users.service';

@Component({
	selector: 'app-user',
	templateUrl: './user.component.html',
	styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit {

	@Input()user!: any;
	@Input()id!: number;

	constructor(private logSrv: LogService, private userSrv: UserService) { }

	ngOnInit(): void {
	}

	onChangeStatus(newStatus: string) {
		this.userSrv.updateUser(this.id, newStatus);
		//this.logSrv.logStatusChange(newStatus);
	}

}
