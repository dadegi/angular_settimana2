export class LogService {
    logStatusChange(newStatus: string) {
        console.log('Nuovo status per l\'utente: ', newStatus)
    }
}