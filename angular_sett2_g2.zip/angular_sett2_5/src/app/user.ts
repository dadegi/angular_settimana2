export interface User {
    nome: string,
    stato: string
}