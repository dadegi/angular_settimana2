import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CutPipe } from './cut.pipe';
import { ActiveUsersPipe } from './active-users.pipe';

@NgModule({
  declarations: [
    AppComponent,
    CutPipe,
    ActiveUsersPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
