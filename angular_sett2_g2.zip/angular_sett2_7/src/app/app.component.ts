import { Component } from '@angular/core';
import { User } from './user';

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.scss']
})
export class AppComponent {
	title = 'angular_sett2_7';
	users: User[] = [
		{
			name: 'Dario',
			house: 'small',
			status: 'online',
			born: new Date(1967,9,20),
			wallet: 30.4
		},
		{
			name: 'Luigi',
			house: 'medium',
			status: 'deleted',
			born: new Date(1973,4,10),
			wallet: 45.7
		},
		{
			name: 'Nicola',
			house: 'large',
			status: 'offline',
			born: new Date(1971,11,18),
			wallet: 15.9
		}
	]

	ngOnInit(): void {
		//Called after the constructor, initializing input properties, and the first call to ngOnChanges.
		//Add 'implements OnInit' to the class.
		setTimeout(() => {
			this.users = [...this.users, {
				name: 'Antonio',
				house: 'medium',
				status: 'online',
				born: new Date(1975,7,1),
				wallet: 50.5
			}]
		}, 1000);
		setTimeout(() => {
			console.log(this.users)
		}, 1500);
	}

	getStatusClasses(user: User) {
		return {
			'list-group-item-success': user.status == 'online',
			'list-group-item-warning': user.status == 'offline',
			'list-group-item-danger': user.status == 'deleted'
		}
	}
}
