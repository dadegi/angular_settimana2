export interface User {
    name: string,
    house: string,
    status: string,
    born: Date,
    wallet: number
}
