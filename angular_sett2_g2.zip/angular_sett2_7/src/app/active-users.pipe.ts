import { Pipe, PipeTransform } from '@angular/core';
import { User } from './user';

@Pipe({
  name: 'activeUsers'
})
export class ActiveUsersPipe implements PipeTransform {

  transform(value: User[], ...args: unknown[]): User[] {
    return value.filter(user => user.status == 'online');
  }

}
