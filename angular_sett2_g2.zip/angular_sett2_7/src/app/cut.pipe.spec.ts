import { CutPipe } from './cut.pipe';

describe('CutPipe', () => {
  it('create an instance', () => {
    const pipe = new CutPipe();
    expect(pipe).toBeTruthy();
  });
});
