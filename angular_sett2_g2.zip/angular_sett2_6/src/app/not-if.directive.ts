import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';

@Directive({
	selector: '[appNotIf]'
})
export class NotIfDirective {

	@Input() set appNotIf(variabile: boolean) {
		if (!variabile) {
			this.cRef.createEmbeddedView(this.templateRef);
		} else {
			this.cRef.clear();
		}
	}

	constructor(private templateRef: TemplateRef<any>, private cRef: ViewContainerRef) { }

}
