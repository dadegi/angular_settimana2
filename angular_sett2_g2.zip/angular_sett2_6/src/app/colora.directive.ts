import { Directive, ElementRef, HostBinding, HostListener, Input, Renderer2 } from '@angular/core';

@Directive({
	selector: '[appColora]'
})
export class ColoraDirective {

	// @HostListener('click') onClick() {
	// 	console.log('host cliccato');
	// }

	@HostListener('mouseenter') mouseEnter() {
		//this.render.setStyle(this.ref.nativeElement, 'color', 'red');
		this.color = this.newColor;
		this.active = true;
	}

	@HostListener('mouseleave') mouseLeave() {
		//this.render.setStyle(this.ref.nativeElement, 'color', 'black');
		this.color = this.newColor;
		this.active = false;
	}

	@Input() defaultColor: string = 'transparent';
	@Input('appColora') newColor: string = 'black';

	@HostBinding('style.color') color: string = 'black';
	@HostBinding('class.active') active: boolean = false;

	constructor(private ref: ElementRef, private render: Renderer2) { }

	ngOnInit(): void {
		//Called after the constructor, initializing input properties, and the first call to ngOnChanges.
		//Add 'implements OnInit' to the class.
		console.log(this.ref);
		//this.ref.nativeElement.style.color = 'red';
		this.color = this.defaultColor;
	}

}
