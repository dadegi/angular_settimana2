import { NotIfDirective } from './not-if.directive';

describe('NotIfDirective', () => {
  it('should create an instance', () => {
    const directive = new NotIfDirective();
    expect(directive).toBeTruthy();
  });
});
