import { ColoraDirective } from './colora.directive';

describe('ColoraDirective', () => {
  it('should create an instance', () => {
    const directive = new ColoraDirective();
    expect(directive).toBeTruthy();
  });
});
