import { Component, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.scss']
})
export class AppComponent {
	title = 'angular_sett2_12';

	@ViewChild('f', { static: true }) form!: NgForm
	userForm = {
		defUsername: 'Dario',
		email: 'dario@dario.com',
		question: 'pet'
	}

	generi = [{ label: 'uomo', value: 'man' }, { label: 'donna', value: 'woman' }];

	risposta = '';

	user: any = {};

	generateUsername() {
		// this.form.form.setValue({
		// 	risposta: '',
		// 	secret: 'pet',
		// 	sesso: "man",
		// 	userInfo: {
		// 		email: "dario@dario.com",
		// 		username: "Darius"
		// 	}
		// });

		this.form.form.patchValue({
			userInfo: {
				email: "pippo@pippo.com",
				username: "pippo"
			}
		})
	}

	ngOnInit(): void {
		//Called after the constructor, initializing input properties, and the first call to ngOnChanges.
		//Add 'implements OnInit' to the class.
		this.form.statusChanges?.subscribe(status => {
			console.log('Stato del form: ', status);
		})
	}

	submit() {
		console.log('form inviato!', this.form);
		this.user.username = this.form.value.userInfo.username;
		this.user.email = this.form.value.userInfo.email;
		this.user.secret = this.form.value.secret;
		this.user.sesso = this.form.value.sesso;
		this.user.risposta = this.form.value.risposta;

		this.form.reset();
	}
}
