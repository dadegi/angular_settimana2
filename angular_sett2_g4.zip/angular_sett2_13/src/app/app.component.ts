import { ValueConverter } from '@angular/compiler/src/render3/view/template';
import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
	title = 'angular_sett2_13';

	generi = ['uomo', 'donna'];
	form!: FormGroup;
	usernameProibiti = ['Luca', 'Marco'];

	constructor(private fb: FormBuilder) {

	}

	usernameProibitiValidatore = (formC: FormControl) => {
		if (this.usernameProibiti.includes(formC.value)) {
			return { 'usernameProibito': true };
		} else {
			return null;
		}
	}

	ngOnInit(): void {
		//Called after the constructor, initializing input properties, and the first call to ngOnChanges.
		//Add 'implements OnInit' to the class.
		this.form = this.fb.group({
			userInfo: this.fb.group({
				username: this.fb.control(null, [Validators.required, this.usernameProibitiValidatore]),
				email: this.fb.control(null, [Validators.required, Validators.email, this.emailProibita]),
			}),
			genere: this.fb.control('uomo'),
			sports: this.fb.array([])
		});

		this.form.valueChanges.subscribe(value => {
			console.log(value);
		})
	}

	// usernameProibitiValidatore(formC: FormControl) {
	// 	if (this.usernameProibiti.includes(formC.value)) {
	// 		return {'usernameProibito': true};
	// 	} else {
	// 		return null;
	// 	}
	// }

	getErrorsC(name: string, error: string) {
		return this.form.get(name)?.errors![error]
	}

	getFormC(name: string) {
		return this.form.get(name);
	}

	getSportsF() {
		return (this.form.get('sports') as FormArray).controls;
	}

	addSports() {
		const control = this.fb.control(null);
		(this.form.get('sports') as FormArray).push(control);
	}

	emailProibita(formC: AbstractControl) {
		return new Promise<ValidationErrors | null>((resolve, reject) => {
			setTimeout(() => {
				if (formC.value == 'prova@prova.com') {
					resolve({ emailProibita: true });
				} else {
					resolve(null);
				}
			}, 2000);
		});
	}

	onSubmit() {
		console.log(this.form);
		this.form.reset();
	}
}
