export interface User {
    sex: string,
    name: string,
    surname: string,
    eta: number
}
