import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserCardComponent } from './components/user-card/user-card.component';
import { NewUserComponent } from './components/new-user/new-user.component';
import { EtaComponent } from './components/eta/eta.component';

@NgModule({
	declarations: [
		AppComponent,
		UserCardComponent,
		NewUserComponent,
		EtaComponent
	],
	imports: [
		BrowserModule,
		AppRoutingModule,
		FormsModule
	],
	providers: [],
	bootstrap: [AppComponent]
})
export class AppModule { }
