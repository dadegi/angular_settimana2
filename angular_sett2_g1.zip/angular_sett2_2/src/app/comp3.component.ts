import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
	selector: 'app-comp3',
	template: `
    <p>
      comp3 works!
    </p>
  `,
	styles: [`
    	p {
      	color: cyan;
    	}
  	`],
	encapsulation: ViewEncapsulation.ShadowDom
})
export class Comp3Component implements OnInit {

	constructor() { }

	ngOnInit(): void {
	}

}
