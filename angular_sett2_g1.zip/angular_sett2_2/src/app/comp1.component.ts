import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
	selector: 'app-comp1',
	template: `
	<h2>ciao comp1</h2>
    <p>
      comp1 works!
    </p>
  `,
	styles: [`
    	p {
    		color: red;
    	}

		h2 {
			color: brown;
		}
  	`
	],
	encapsulation: ViewEncapsulation.Emulated
})
export class Comp1Component implements OnInit {

	constructor() { }

	ngOnInit(): void {
	}

}
