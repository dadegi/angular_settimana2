import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
	selector: 'app-comp2',
	template: `
  <h2>ciao comp2</h2>
    <p>
      comp2 works!
    </p>
  `,
	styles: [`
    	h2 {
			color: yellow;
		}
  	`],
	encapsulation: ViewEncapsulation.None
})
export class Comp2Component implements OnInit {

	constructor() { }

	ngOnInit(): void {
	}

}
