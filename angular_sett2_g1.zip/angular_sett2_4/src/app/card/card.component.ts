import { ChildComponent } from './../child/child.component';
import { Component, Input, OnInit, ViewChild } from '@angular/core';

@Component({
	selector: 'app-card',
	templateUrl: './card.component.html',
	styleUrls: ['./card.component.scss']
})
export class CardComponent implements OnInit {

	@ViewChild(ChildComponent, {static: true}) child!: ChildComponent;
	@ViewChild('ciao', {static: true}) ciao!: any;

	constructor() { }

	ngOnInit(): void {
		console.log(this.child.nome);
		console.log(this.ciao);
	}

	ngAfterViewInit(): void {
		//Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
		//Add 'implements AfterViewInit' to the class.
		console.log(this.child.nome);
		console.log(this.ciao);
	}

	// visualizza(i: any) {
	// 	console.log(i.value);
	// }

}
